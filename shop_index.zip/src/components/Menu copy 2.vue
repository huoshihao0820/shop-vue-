<template>
  <div class="menu">
    <div class="content">
   <div class="left"></div>
   <div class="con"></div>
   <div class="right"></div>
    </div>
  </div>
</template>
<style lang="scss" >
.menu {
  .content {
    display: flex;
    align-items: center;
    justify-content: space-between;
  
  }
}
</style>
<script>
export default {
  data() {
    return {
      ishedden: false,
    };
  },
  methods: {},
};
</script>